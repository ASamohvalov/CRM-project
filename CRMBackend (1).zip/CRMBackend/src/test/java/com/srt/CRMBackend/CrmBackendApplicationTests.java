package com.srt.CRMBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
